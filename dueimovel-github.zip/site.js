// Shared behaviour for every DueImóvel page (home, entrar, and whatever comes next).
// Every block below checks that its elements exist before touching them, so this
// same file can be safely included on pages that don't have a full nav/hero.

document.addEventListener('DOMContentLoaded', function () {
  var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---- glass "spotlight" that follows the mouse on buttons/cards ----
  document.querySelectorAll('.js-glass, .js-tilt').forEach(function (el) {
    el.addEventListener('pointermove', function (e) {
      var r = el.getBoundingClientRect();
      el.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      el.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
  });

  // ---- nav: solid glass once the page scrolls past the hero ----
  var nav = document.getElementById('mainNav');
  var hero = document.getElementById('top');
  if (nav && hero) {
    var updateNav = function () {
      var threshold = hero.offsetHeight - 100;
      if (window.scrollY > threshold) { nav.classList.add('is-scrolled'); }
      else { nav.classList.remove('is-scrolled'); }
    };
    document.addEventListener('scroll', updateNav, { passive: true });
    updateNav();
  } else if (nav) {
    // pages without a tall hero (like the login page) start with the solid nav
    nav.classList.add('is-scrolled');
  }

  // ---- mobile menu ----
  var burger = document.getElementById('burgerBtn');
  var panel = document.getElementById('mobilePanel');
  if (burger && panel) {
    burger.addEventListener('click', function () {
      var open = panel.classList.toggle('open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    panel.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { panel.classList.remove('open'); });
    });
  }

  // ---- small "em breve" toast, used for parts still under construction ----
  var toast = document.getElementById('toast');
  var toastTimer = null;
  window.showToast = function (msg) {
    if (!toast) { return; }
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.classList.remove('show'); }, 2600);
  };
  document.querySelectorAll('.js-soon').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      window.showToast('Essa parte ainda está em construção 🏗️ — em breve!');
    });
  });

  // ---- personaliza o chip de perfil e a saudação com o nome digitado no
  // login/cadastro (guardado só no navegador da pessoa, sem servidor) ----
  (function personalizeProfile() {
    var nome;
    try { nome = localStorage.getItem('duelmovel_nome'); } catch (err) { nome = null; }
    if (!nome) { return; }
    var iniciais = nome.trim().split(/\s+/).slice(0, 2).map(function (p) {
      return p.charAt(0).toUpperCase();
    }).join('');
    document.querySelectorAll('.app-profile-name').forEach(function (el) { el.textContent = nome; });
    document.querySelectorAll('.app-profile-avatar').forEach(function (el) { el.textContent = iniciais; });
    var greet = document.getElementById('greetName');
    if (greet) { greet.textContent = nome.split(/\s+/)[0]; }
    var cfgNome = document.getElementById('cfgNome');
    if (cfgNome) { cfgNome.value = nome; }
  })();

  document.querySelectorAll('.app-logout').forEach(function (el) {
    el.addEventListener('click', function () {
      try { localStorage.removeItem('duelmovel_nome'); } catch (err) { /* sem problema */ }
    });
  });

  // ---- anel de "quantas análises já foram usadas no plano": desenha o
  // preenchimento e conta o número ao aparecer na tela, em vez de só mostrar
  // o valor parado ----
  (function initUsageRings() {
    // observamos o ".ring-wrap" (não o SVG do anel direto) porque esse wrap
    // é o que realmente fica visível na tela, então o IntersectionObserver
    // consegue detectar quando ele aparece pra disparar a animação.
    var wraps = document.querySelectorAll('.ring-wrap');
    if (!wraps.length) { return; }

    function animateRing(wrap) {
      var svg = wrap.querySelector('.usage-ring');
      if (!svg) { return; }
      var used = parseFloat(svg.getAttribute('data-used')) || 0;
      var total = parseFloat(svg.getAttribute('data-total')) || 1;
      var fill = svg.querySelector('.ring-fill');
      var label = svg.querySelector('.ring-value');
      var fraction = Math.max(0, Math.min(1, used / total));

      var barFill = wrap.querySelector('.usage-bar-fill');
      var barValue = wrap.querySelector('.usage-bar-value');
      if (barFill) { barFill.style.width = (fraction * 100).toFixed(1) + '%'; }
      if (barValue) { barValue.textContent = used + ' / ' + total; }

      if (!fill) { return; }
      var radius = parseFloat(fill.getAttribute('r'));
      var circumference = 2 * Math.PI * radius;

      fill.style.strokeDasharray = circumference.toFixed(1);
      fill.style.strokeDashoffset = circumference.toFixed(1);
      fill.style.stroke = fraction >= 0.8 ? '#a3562b' : (fraction >= 0.5 ? 'var(--accent)' : 'var(--green)');

      if (prefersReducedMotion) {
        fill.style.strokeDashoffset = (circumference * (1 - fraction)).toFixed(1);
        if (label) { label.textContent = used + ' / ' + total; }
        return;
      }

      requestAnimationFrame(function () {
        fill.style.transition = 'stroke-dashoffset 1.1s cubic-bezier(.2,.8,.2,1)';
        fill.style.strokeDashoffset = (circumference * (1 - fraction)).toFixed(1);
      });

      if (label) {
        var start = null;
        var duration = 900;
        var step = function (ts) {
          if (!start) { start = ts; }
          var progress = Math.min(1, (ts - start) / duration);
          label.textContent = Math.round(progress * used) + ' / ' + total;
          if (progress < 1) { requestAnimationFrame(step); }
        };
        requestAnimationFrame(step);
      }
    }

    if ('IntersectionObserver' in window) {
      var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateRing(entry.target);
            obs.unobserve(entry.target);
          }
        });
      }, { threshold: 0.4 });
      wraps.forEach(function (w) { obs.observe(w); });
    } else {
      wraps.forEach(animateRing);
    }
  })();

  // ---- barrinhas de progresso pequenas (rodapé dos cards de imóvel, o
  // resumo "Seu mês" do Início e as linhas de "Minhas análises") — cada
  // uma só lê a largura final de data-fraction e anima até lá quando
  // entra na tela, mesmo truque de sempre pra não animar coisa escondida ----
  (function initMiniProgress() {
    var fills = document.querySelectorAll('.mini-progress-fill[data-fraction]');
    if (!fills.length) { return; }
    function apply(el) {
      var fraction = Math.max(0, Math.min(1, parseFloat(el.getAttribute('data-fraction')) || 0));
      el.style.width = (fraction * 100).toFixed(0) + '%';
    }
    if ('IntersectionObserver' in window) {
      var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            apply(entry.target);
            obs.unobserve(entry.target);
          }
        });
      }, { threshold: 0.3 });
      fills.forEach(function (el) { obs.observe(el); });
    } else {
      fills.forEach(apply);
    }
  })();

  // ---- filtros por status (chips), reaproveitados em "Meus imóveis" e
  // "Minhas análises" — pedido da Isa numa mensagem com mockups, pra sair
  // do jeito "galeria"/"tabela simples" das duas telas. Função genérica
  // porque as duas páginas usam a mesma lógica (clicou no chip, mostra só
  // os itens daquele status, e se não sobrar nenhum mostra o aviso de
  // "vazio" que já existia no site) ----
  function initStatusFilter(chipsSelector, itemsSelector, emptySelector) {
    var chips = document.querySelectorAll(chipsSelector);
    var items = document.querySelectorAll(itemsSelector);
    if (!chips.length || !items.length) { return; }
    var empty = emptySelector ? document.querySelector(emptySelector) : null;
    chips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        chips.forEach(function (c) { c.classList.remove('is-active'); });
        chip.classList.add('is-active');
        var filter = chip.getAttribute('data-filter');
        var anyVisible = false;
        items.forEach(function (item) {
          var match = filter === 'todos' || item.getAttribute('data-status') === filter;
          item.style.display = match ? '' : 'none';
          if (match) { anyVisible = true; }
        });
        if (empty) { empty.classList.toggle('is-visible', !anyVisible); }
      });
    });
  }
  initStatusFilter('.imoveis-filters .filter-chip', '.property-grid .property-card', '.imoveis-empty');
  initStatusFilter('.analises-filters .filter-chip', '.resumo-list .analysis-row', '.analises-empty');

  // ---- logo fixa no canto inferior esquerdo, em todas as páginas, sempre
  // visível mesmo rolando a tela (pedido da Isa) ----
  (function initBrandBadge() {
    if (document.getElementById('brandBadge')) { return; }
    // nas páginas do painel logado já existe uma logo fixa (a barra lateral
    // é "sticky" e mostra "DueImóvel" o tempo todo) bem no canto onde essa
    // bolinha ficaria — pra não sobrepor o avatar da pessoa ali embaixo, a
    // bolinha só aparece nas páginas sem barra lateral (homepage e login)
    if (document.querySelector('.app-sidebar')) { return; }
    var badge = document.createElement('a');
    badge.href = 'index.html';
    badge.id = 'brandBadge';
    badge.className = 'brand-badge';
    badge.setAttribute('aria-label', 'DueImóvel — página inicial');
    badge.title = 'DueImóvel';
    badge.innerHTML = '<img src="logo-dueimovel.png" alt="" class="brand-badge-img-1">';
    document.body.appendChild(badge);
  })();

  // ---- prévia de "relatório em PDF" no Resumo executivo — pedido da Isa:
  // um botão extra que abre um exemplo de leitura (não gera PDF de
  // verdade), com uma logo enorme e apagada no fundo, tipo marca d'água ----
  (function initPdfPreview() {
    var trigger = document.getElementById('pdfPreviewBtn');
    var modal = document.getElementById('pdfModal');
    if (!trigger || !modal) { return; }
    function open() {
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
    }
    function close() {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
    }
    trigger.addEventListener('click', open);
    modal.querySelectorAll('[data-pdf-close]').forEach(function (el) {
      el.addEventListener('click', close);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('is-open')) { close(); }
    });
    var downloadBtn = document.getElementById('pdfDownloadBtn');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', function () {
        window.showToast('Isso é só um exemplo — nenhum PDF foi gerado de verdade.');
      });
    }
  })();

  // ---- generic tabs, used on the analysis pages inside the app ----
  (function initTabs() {
    var bars = document.querySelectorAll('.tabbar');
    if (!bars.length) { return; }
    var panels = document.querySelectorAll('[data-tab-panel]');
    bars.forEach(function (bar) {
      var buttons = bar.querySelectorAll('button[data-tab]');
      buttons.forEach(function (btn) {
        btn.addEventListener('click', function () {
          buttons.forEach(function (b) { b.classList.remove('is-active'); });
          btn.classList.add('is-active');
          var target = btn.getAttribute('data-tab');
          panels.forEach(function (p) {
            p.classList.toggle('is-active', p.getAttribute('data-tab-panel') === target);
          });
        });
      });
    });
  })();

  // ---- scroll reveal: elements are visible by default (safe fallback);
  // JS only hides, briefly, the ones currently below the fold, then reveals
  // them with a soft fade+rise as the user scrolls to them ----
  (function initReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!els.length || prefersReducedMotion || !('IntersectionObserver' in window)) { return; }
    els.forEach(function (el, i) {
      var rect = el.getBoundingClientRect();
      if (rect.top > window.innerHeight * 0.9) {
        el.classList.add('reveal-pending');
        el.style.transitionDelay = ((i % 3) * 80) + 'ms';
      }
    });
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.remove('reveal-pending');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });
    els.forEach(function (el) { obs.observe(el); });
  })();

  // ---- subtle 3D tilt on cards, following the cursor ----
  if (!prefersReducedMotion && window.matchMedia('(hover: hover)').matches) {
    document.querySelectorAll('.js-tilt3d').forEach(function (el) {
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width - 0.5;
        var py = (e.clientY - r.top) / r.height - 0.5;
        el.style.setProperty('--ry', (px * 8) + 'deg');
        el.style.setProperty('--rx', (py * -8) + 'deg');
        el.style.setProperty('--ty', '-4px');
      });
      el.addEventListener('pointerleave', function () {
        el.style.setProperty('--rx', '0deg');
        el.style.setProperty('--ry', '0deg');
        el.style.setProperty('--ty', '0px');
      });
    });
  }

  // ---- gentle parallax on a full-bleed photo section while scrolling ----
  if (!prefersReducedMotion) {
    document.querySelectorAll('.js-parallax').forEach(function (section) {
      var ticking = false;
      document.addEventListener('scroll', function () {
        if (ticking) { return; }
        ticking = true;
        requestAnimationFrame(function () {
          var y = window.scrollY;
          if (y < section.offsetHeight) {
            section.style.backgroundPositionY = (62 + y * 0.02) + '%';
          }
          ticking = false;
        });
      }, { passive: true });
    });
  }

  // ---- highlight the current section in the nav as you scroll ----
  (function initActiveNav() {
    var sectionIds = ['plataforma', 'para-quem-e', 'como-funciona', 'planos'];
    var sections = sectionIds.map(function (id) { return document.getElementById(id); }).filter(Boolean);
    var navLinks = document.querySelectorAll('.nav-links a, .nav-mobile-panel a');
    if (!sections.length || !navLinks.length || !('IntersectionObserver' in window)) { return; }
    var current = null;
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { current = entry.target.id; }
      });
      navLinks.forEach(function (a) {
        var match = a.getAttribute('href') === ('#' + current);
        a.classList.toggle('is-active', match);
      });
    }, { rootMargin: '-45% 0px -50% 0px', threshold: 0 });
    sections.forEach(function (s) { obs.observe(s); });
  })();
});
