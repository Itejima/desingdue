# DueImóvel — protótipo do site

Protótipo visual (sem backend de verdade) de uma plataforma de diagnóstico de risco imobiliário. Site institucional + um painel logado de exemplo, com dados fictícios.

> Este pacote reflete a versão publicada em 2026-10-10 (Versão 49 no Claude), já sem o alternador de visuais "Interface 1/2/3" que existia antes — agora o site tem um visual só.

## Como abrir o site (sem precisar instalar nada)

1. Baixe/extraia esta pasta no seu computador.
2. Dê dois cliques no arquivo `index.html`. Ele abre direto no seu navegador (Chrome, Edge, etc.) — não precisa de servidor, internet especial nem nenhum programa a mais.
3. Pra navegar pelo painel logado (depois de clicar em "Entrar" ou "Testar grátis"), é só continuar clicando nos links normalmente.

Algumas fontes (letras) são carregadas da internet (Google Fonts), então é bom estar conectado à internet pra elas aparecerem certinho — sem internet o site ainda funciona, só troca pra uma fonte padrão do sistema.

## O que tem em cada arquivo

- `index.html` — página inicial (site institucional): hero, "A plataforma", "Para quem é", "Como funciona", "Planos".
- `entrar.html` — tela de login e cadastro.
- `app-inicio.html` — painel principal depois de entrar (dashboard).
- `app-imoveis.html` — lista de imóveis analisados.
- `app-imovel.html` — detalhe da análise de um imóvel específico.
- `app-proprietario.html` — detalhe da análise de um proprietário.
- `app-analises.html` — histórico de todas as análises.
- `app-resumo.html` — resumo executivo de uma análise (com um exemplo de "relatório em PDF").
- `app-favoritos.html` — imóveis favoritados.
- `app-plano.html` — plano/assinatura da conta.
- `app-configuracoes.html` — configurações da conta.
- `styles.css` — todo o visual do site (cores, fontes, layout, responsivo pra celular).
- `site.js` — todo o comportamento interativo (menus, filtros, animações, avisos de "em construção" etc.).
- `hero.jpg`, `map-example.jpg`, `logo-dueimovel.png` — as imagens usadas no site.

## O que é só exemplo (não é de verdade)

- Os nomes, CPFs, endereços e números de matrícula são fictícios.
- "Entrar" e "Cadastro" não criam uma conta de verdade — só guardam o nome digitado no navegador (pra personalizar a saudação), sem enviar nada pra nenhum servidor.
- Botões como "Nova análise", busca, filtros de ordenação e "Baixar PDF" mostram um aviso de "ainda em construção" — são espaços reservados pra funcionalidades futuras.
- Não existe um banco de dados real por trás — é tudo HTML/CSS/JavaScript "puro", sem nenhum backend.

## Como subir isso pro GitHub (passo a passo, sem usar terminal)

Se você já tem uma conta no GitHub (github.com):

1. Entre em github.com e clique no "+" no canto superior direito → **New repository**.
2. Dê um nome pro repositório (ex.: `dueimovel`), deixe como **Public** ou **Private** (sua escolha) e clique em **Create repository**.
3. Na página do repositório recém-criado, clique no link **"uploading an existing file"** (ou no botão **Add file → Upload files**, se já tiver conteúdo).
4. Arraste todos os arquivos desta pasta (os `.html`, o `.css`, o `.js` e as 3 imagens) pra dentro da área de upload do GitHub.
5. Role pra baixo, escreva uma mensagem curta tipo "primeira versão do site" em **Commit changes**, e clique no botão verde **Commit changes**.
6. Pronto — os arquivos já estão no seu GitHub. Se quiser que o site fique acessível por um link público (tipo um site de verdade, não só os arquivos), dá pra ativar o **GitHub Pages**: vá em **Settings** do repositório → **Pages** (no menu da esquerda) → em "Source" escolha a branch `main` e a pasta `/ (root)` → **Save**. Em alguns minutos o GitHub te dá um link (algo como `https://seu-usuario.github.io/dueimovel/`) onde o site fica no ar de verdade, sem precisar baixar nada.

Qualquer mudança futura no site (que eu fizer aqui com você) pode ser reenviada do mesmo jeito: repetir os passos 3 a 5 com os arquivos atualizados — o GitHub substitui os antigos automaticamente.
